from django.apps import AppConfig


class OrganigramaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'organigrama'
