from django.contrib import admin
from .models import SubirArchivo

admin.site.register(SubirArchivo)